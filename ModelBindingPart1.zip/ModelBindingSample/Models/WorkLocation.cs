﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ModelBindingSample.Models
{
    public class WorkLocation
    {
        public string BuildingName { get; set; }
        public string Description { get; set; }
    }
}